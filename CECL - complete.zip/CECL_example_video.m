% Circular-based Eye Center Localization (CECL) example (video)
% Based on paper: 
% Author: Yustinus Eko Soelistio, Eric Postma, Alfons Maes
% Last update: Dec. 11, 2014

fileName = 'test.avi';
videoFrame = vision.VideoFileReader(fileName);
frameInImage = step(videoFrame);

while ~isDone(videoFrame)
    image = frameInImage;    
    [x1, y1, r1, x2, y2, r2] = CECL(rgb2gray(image));
    figure(1), imshow(image), title(imageFile), hold on, viscircles([x1 y1], r1, 'EdgeColor', 'g', 'LineWidth', 1), hold on; viscircles([x2 y2], r2, 'EdgeColor', 'g', 'LineWidth', 1), hold off;    
    frameInImage = step(videoFrame);
end
